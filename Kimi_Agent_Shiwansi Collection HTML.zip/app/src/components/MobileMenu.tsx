import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import gsap from 'gsap';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const navLinks = [
  { label: 'Collections', href: '/#collections' },
  { label: 'About', href: '/#about' },
  { label: 'Services', href: '/#services' },
  { label: 'Visit Us', href: '/#visit' },
  { label: 'Contact', href: '/#contact' },
];

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const linksRef = useRef<HTMLAnchorElement[]>([]);

  useEffect(() => {
    if (isOpen) {
      gsap.fromTo(
        linksRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          stagger: 0.08,
          ease: 'power3.out',
          delay: 0.15,
        }
      );
    }
  }, [isOpen]);

  const handleClick = (href: string) => {
    onClose();
    if (href.startsWith('/#')) {
      const id = href.replace('/#', '');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 400);
    }
  };

  return (
    <div className={`mobile-overlay ${isOpen ? 'active' : ''}`}>
      <button
        onClick={onClose}
        style={{
          position: 'absolute',
          top: '30px',
          right: '30px',
          background: 'none',
          border: 'none',
          color: 'var(--warm-white)',
          cursor: 'pointer',
        }}
      >
        <X size={24} />
      </button>
      {navLinks.map((link, i) => (
        <a
          key={link.label}
          href={link.href}
          ref={(el) => { if (el) linksRef.current[i] = el; }}
          onClick={(e) => {
            e.preventDefault();
            handleClick(link.href);
          }}
        >
          {link.label}
        </a>
      ))}
    </div>
  );
}
