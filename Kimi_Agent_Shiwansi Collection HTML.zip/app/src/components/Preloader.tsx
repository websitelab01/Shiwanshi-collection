import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

interface PreloaderProps {
  loading: boolean;
}

export default function Preloader({ loading }: PreloaderProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const tl = gsap.timeline();
    
    tl.to(lineRef.current, {
      scaleX: 1,
      duration: 2.2,
      ease: 'power2.inOut',
    });

    const obj = { val: 0 };
    gsap.to(obj, {
      val: 100,
      duration: 2.2,
      ease: 'power2.inOut',
      onUpdate: () => {
        setCount(Math.round(obj.val));
      },
    });
  }, []);

  useEffect(() => {
    if (!loading && containerRef.current) {
      containerRef.current.classList.add('hidden');
    }
  }, [loading]);

  return (
    <div ref={containerRef} className="preloader">
      <div style={{ textAlign: 'center' }}>
        <div className="preloader-wordmark">SHIWANSI</div>
        <div className="preloader-line-container">
          <div
            ref={lineRef}
            className="preloader-line"
            style={{ transformOrigin: 'center' }}
          />
          <span className="preloader-counter">{count}%</span>
        </div>
        <div className="preloader-tagline">COLLECTION</div>
      </div>
    </div>
  );
}
