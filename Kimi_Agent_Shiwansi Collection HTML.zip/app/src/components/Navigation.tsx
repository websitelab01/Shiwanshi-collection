import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, ShoppingBag, User, Menu } from 'lucide-react';
import MobileMenu from './MobileMenu';
import { useCartStore } from '../store/cartStore';

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const totalItems = useCartStore((s) => s.getTotalItems());
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    if (isHome) {
      e.preventDefault();
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const textColor = scrolled || !isHome ? 'var(--ink)' : 'var(--warm-white)';
  const bgStyle = scrolled || !isHome
    ? { background: 'rgba(247,245,242,0.9)', backdropFilter: 'blur(20px) saturate(180%)' }
    : { background: 'transparent' };

  return (
    <>
      <MobileMenu isOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <nav
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 1000,
          padding: scrolled ? '16px 48px' : '24px 48px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          transition: 'all 0.4s ease',
          ...bgStyle,
        }}
      >
        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileOpen(true)}
          style={{
            display: 'none',
            background: 'none',
            border: 'none',
            color: textColor,
            cursor: 'pointer',
            transition: 'color 0.3s',
          }}
          className="mobile-hamburger"
        >
          <Menu size={22} />
        </button>

        {/* Logo */}
        <Link to="/" style={{ textDecoration: 'none', textAlign: 'center' }}>
          <div
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 600,
              fontSize: '16px',
              letterSpacing: '5px',
              color: textColor,
              textTransform: 'uppercase',
              lineHeight: 1.2,
              transition: 'color 0.3s',
            }}
          >
            SHIWANSI
          </div>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '8px',
              letterSpacing: '4px',
              color: textColor,
              textTransform: 'uppercase',
              transition: 'color 0.3s',
              opacity: 0.8,
            }}
          >
            COLLECTION
          </div>
        </Link>

        {/* Desktop Nav Links */}
        <ul
          style={{
            display: 'flex',
            gap: '36px',
            listStyle: 'none',
            margin: 0,
            padding: 0,
            alignItems: 'center',
          }}
          className="desktop-nav-links"
        >
          {[
            { label: 'Collections', id: 'collections' },
            { label: 'About', id: 'about' },
            { label: 'Services', id: 'services' },
            { label: 'Visit Us', id: 'visit' },
          ].map((link) => (
            <li key={link.id}>
              <a
                href={`/#${link.id}`}
                onClick={(e) => handleNavClick(e, link.id)}
                className="nav-link"
                style={{
                  textDecoration: 'none',
                  color: textColor,
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                  fontSize: '11px',
                  letterSpacing: '2.5px',
                  textTransform: 'uppercase',
                  position: 'relative',
                  transition: 'color 0.3s',
                }}
              >
                {link.label}
                <span className="nav-link-underline" style={{ background: textColor }} />
              </a>
            </li>
          ))}
        </ul>

        {/* Nav Icons */}
        <div style={{ display: 'flex', gap: '22px', alignItems: 'center' }}>
          <Link
            to="/search"
            style={{ color: textColor, transition: 'color 0.3s', position: 'relative' }}
            className="nav-icon-link"
          >
            <Search size={18} strokeWidth={1.5} />
          </Link>
          <Link
            to="/cart"
            style={{ color: textColor, transition: 'color 0.3s', position: 'relative' }}
            className="nav-icon-link"
          >
            <ShoppingBag size={18} strokeWidth={1.5} />
            {totalItems > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: '-6px',
                  right: '-8px',
                  background: 'var(--gold)',
                  color: 'var(--ink)',
                  fontSize: '9px',
                  fontWeight: 600,
                  width: '16px',
                  height: '16px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: "'Inter', sans-serif",
                }}
              >
                {totalItems}
              </span>
            )}
          </Link>
          <Link
            to="/profile"
            style={{ color: textColor, transition: 'color 0.3s' }}
            className="nav-icon-link"
          >
            <User size={18} strokeWidth={1.5} />
          </Link>
          <button
            onClick={() => setMobileOpen(true)}
            style={{
              display: 'none',
              background: 'none',
              border: 'none',
              color: textColor,
              cursor: 'pointer',
              transition: 'color 0.3s',
            }}
            className="mobile-menu-btn"
          >
            <Menu size={22} />
          </button>
        </div>
      </nav>

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav-links {
            display: none !important;
          }
          .mobile-hamburger {
            display: block !important;
          }
          .mobile-menu-btn {
            display: block !important;
          }
          nav {
            padding: 16px 24px !important;
          }
        }
        .nav-icon-link:hover {
          color: var(--gold) !important;
        }
      `}</style>
    </>
  );
}
