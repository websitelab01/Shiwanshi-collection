import { Link } from 'react-router-dom';
import { Facebook, Instagram, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer
      id="contact"
      style={{
        background: 'var(--ink)',
        color: 'var(--warm-white)',
        padding: '80px 48px 30px',
      }}
    >
      <div
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: '2fr 1fr 1fr 1fr',
          gap: '60px',
          marginBottom: '60px',
        }}
        className="footer-grid"
      >
        {/* Brand Column */}
        <div>
          <div
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 600,
              fontSize: '24px',
              letterSpacing: '6px',
              marginBottom: '20px',
              color: 'var(--warm-white)',
            }}
          >
            SHIWANSI
          </div>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '14px',
              lineHeight: 1.7,
              color: 'rgba(247,245,242,0.55)',
              marginBottom: '25px',
            }}
          >
            Curating style for every generation in the heart of Itahari. Quality
            fashion, inclusive values, and a shopping experience that feels like
            home.
          </p>
          <div style={{ display: 'flex', gap: '15px' }}>
            {[Facebook, Instagram, MessageCircle].map((Icon, i) => (
              <a
                key={i}
                href="#"
                style={{
                  width: '40px',
                  height: '40px',
                  border: '1px solid rgba(247,245,242,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'rgba(247,245,242,0.5)',
                  textDecoration: 'none',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background = 'var(--gold)';
                  (e.currentTarget as HTMLElement).style.borderColor = 'var(--gold)';
                  (e.currentTarget as HTMLElement).style.color = 'var(--ink)';
                  (e.currentTarget as HTMLElement).style.transform = 'translateY(-3px)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background = 'transparent';
                  (e.currentTarget as HTMLElement).style.borderColor = 'rgba(247,245,242,0.2)';
                  (e.currentTarget as HTMLElement).style.color = 'rgba(247,245,242,0.5)';
                  (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                }}
              >
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>

        {/* Collections */}
        <div>
          <h4
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
              fontSize: '10px',
              letterSpacing: '2px',
              textTransform: 'uppercase',
              marginBottom: '25px',
              color: 'var(--warm-white)',
            }}
          >
            Collections
          </h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {["Men's Wear", "Women's Wear", "Baby Wear", 'New Arrivals'].map(
              (item) => (
                <li key={item} style={{ marginBottom: '12px' }}>
                  <Link
                    to="/"
                    style={{
                      color: 'rgba(247,245,242,0.5)',
                      textDecoration: 'none',
                      fontSize: '14px',
                      fontFamily: "'Inter', sans-serif",
                      transition: 'color 0.25s',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'rgba(247,245,242,0.5)';
                    }}
                  >
                    {item}
                  </Link>
                </li>
              )
            )}
          </ul>
        </div>

        {/* Services */}
        <div>
          <h4
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
              fontSize: '10px',
              letterSpacing: '2px',
              textTransform: 'uppercase',
              marginBottom: '25px',
              color: 'var(--warm-white)',
            }}
          >
            Services
          </h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {[
              'In-Store Shopping',
              'In-Store Pick-up',
              'Home Delivery',
              'Gift Cards',
            ].map((item) => (
              <li key={item} style={{ marginBottom: '12px' }}>
                <a
                  href="#"
                  style={{
                    color: 'rgba(247,245,242,0.5)',
                    textDecoration: 'none',
                    fontSize: '14px',
                    fontFamily: "'Inter', sans-serif",
                    transition: 'color 0.25s',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = 'rgba(247,245,242,0.5)';
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Company */}
        <div>
          <h4
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
              fontSize: '10px',
              letterSpacing: '2px',
              textTransform: 'uppercase',
              marginBottom: '25px',
              color: 'var(--warm-white)',
            }}
          >
            Company
          </h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {['About Us', 'Our Story', 'Sustainability', 'Careers'].map(
              (item) => (
                <li key={item} style={{ marginBottom: '12px' }}>
                  <a
                    href="#"
                    style={{
                      color: 'rgba(247,245,242,0.5)',
                      textDecoration: 'none',
                      fontSize: '14px',
                      fontFamily: "'Inter', sans-serif",
                      transition: 'color 0.25s',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'rgba(247,245,242,0.5)';
                    }}
                  >
                    {item}
                  </a>
                </li>
              )
            )}
          </ul>
        </div>
      </div>

      {/* Bottom Bar */}
      <div
        style={{
          borderTop: '1px solid rgba(247,245,242,0.06)',
          paddingTop: '30px',
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '12px',
          color: 'rgba(247,245,242,0.35)',
          fontFamily: "'Inter', sans-serif",
        }}
        className="footer-bottom"
      >
        <p>&copy; 2025 Shiwansi Collection. All rights reserved.</p>
        <p>Itahari, Nepal</p>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .footer-grid {
            grid-template-columns: 1fr !important;
            gap: 40px !important;
          }
          .footer-bottom {
            flex-direction: column !important;
            gap: 10px;
            text-align: center;
          }
        }
      `}</style>
    </footer>
  );
}
