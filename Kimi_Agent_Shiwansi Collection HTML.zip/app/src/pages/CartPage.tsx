import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Trash2, Plus, Minus, Package } from 'lucide-react';
import gsap from 'gsap';
import { useCartStore } from '../store/cartStore';
import Footer from '../components/Footer';

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotalPrice, clearCart } = useCartStore();

  useEffect(() => {
    window.scrollTo(0, 0);
    gsap.fromTo(
      '.cart-fade-in',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', stagger: 0.1 }
    );
  }, []);

  const formatPrice = (p: number) => `Rs. ${p.toLocaleString()}`;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--warm-white)' }}>
      <div style={{ padding: '120px 48px 40px', maxWidth: '1000px', margin: '0 auto' }}>
        <Link
          to="/"
          className="cart-fade-in"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            color: 'var(--warm-grey)',
            textDecoration: 'none',
            fontFamily: "'Inter', sans-serif",
            fontSize: '13px',
            letterSpacing: '1px',
            textTransform: 'uppercase',
            marginBottom: '40px',
            transition: 'color 0.3s',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
          }}
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          Back to Home
        </Link>

        <h1
          className="cart-fade-in"
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 300,
            fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
            letterSpacing: '-1.2px',
            color: 'var(--ink)',
            marginBottom: '16px',
          }}
        >
          Shopping Cart
        </h1>

        <p
          className="cart-fade-in"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '15px',
            color: 'var(--warm-grey)',
            marginBottom: '48px',
          }}
        >
          {items.length} {items.length === 1 ? 'item' : 'items'} in your cart
        </p>

        {items.length > 0 ? (
          <div>
            {/* Cart Items */}
            <div className="cart-fade-in" style={{ marginBottom: '40px' }}>
              {items.map((item) => (
                <div
                  key={item.id}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '100px 1fr auto',
                    gap: '24px',
                    alignItems: 'center',
                    padding: '24px 0',
                    borderBottom: '1px solid var(--muted)',
                  }}
                  className="cart-item"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    style={{
                      width: '100px',
                      height: '120px',
                      objectFit: 'cover',
                    }}
                  />
                  <div>
                    <span
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: '10px',
                        fontWeight: 600,
                        letterSpacing: '1.5px',
                        textTransform: 'uppercase',
                        color: 'var(--gold)',
                      }}
                    >
                      {item.category}
                    </span>
                    <h3
                      style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontWeight: 400,
                        fontSize: '20px',
                        color: 'var(--ink)',
                        marginTop: '4px',
                        marginBottom: '8px',
                      }}
                    >
                      {item.name}
                    </h3>
                    <span
                      style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontWeight: 600,
                        fontSize: '18px',
                        color: 'var(--gold)',
                      }}
                    >
                      {formatPrice(item.price)}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    {/* Quantity controls */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        border: '1px solid var(--muted)',
                      }}
                    >
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.quantity - 1)
                        }
                        style={{
                          background: 'none',
                          border: 'none',
                          padding: '8px 12px',
                          cursor: 'pointer',
                          color: 'var(--ink)',
                        }}
                      >
                        <Minus size={14} strokeWidth={1.5} />
                      </button>
                      <span
                        style={{
                          fontFamily: "'Inter', sans-serif",
                          fontSize: '13px',
                          fontWeight: 600,
                          color: 'var(--ink)',
                          padding: '0 8px',
                          minWidth: '24px',
                          textAlign: 'center',
                        }}
                      >
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.quantity + 1)
                        }
                        style={{
                          background: 'none',
                          border: 'none',
                          padding: '8px 12px',
                          cursor: 'pointer',
                          color: 'var(--ink)',
                        }}
                      >
                        <Plus size={14} strokeWidth={1.5} />
                      </button>
                    </div>
                    {/* Subtotal */}
                    <span
                      style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontWeight: 600,
                        fontSize: '18px',
                        color: 'var(--ink)',
                        minWidth: '100px',
                        textAlign: 'right',
                      }}
                    >
                      {formatPrice(item.price * item.quantity)}
                    </span>
                    {/* Delete */}
                    <button
                      onClick={() => removeItem(item.id)}
                      style={{
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        color: 'var(--warm-grey)',
                        padding: '8px',
                        transition: 'color 0.3s',
                      }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLElement).style.color = '#c44';
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
                      }}
                    >
                      <Trash2 size={16} strokeWidth={1.5} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Cart Summary */}
            <div
              className="cart-fade-in"
              style={{
                background: 'var(--cream)',
                padding: '40px',
                marginBottom: '40px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '24px',
                }}
              >
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '14px',
                    color: 'var(--warm-grey)',
                    textTransform: 'uppercase',
                    letterSpacing: '1.5px',
                  }}
                >
                  Subtotal
                </span>
                <span
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontWeight: 600,
                    fontSize: '28px',
                    color: 'var(--ink)',
                  }}
                >
                  {formatPrice(getTotalPrice())}
                </span>
              </div>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '13px',
                  color: 'var(--warm-grey)',
                  lineHeight: 1.6,
                  marginBottom: '24px',
                }}
              >
                Shipping and taxes calculated at checkout. Home delivery
                available across Itahari and surrounding areas.
              </p>
              <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                <button
                  style={{
                    flex: 1,
                    minWidth: '200px',
                    padding: '16px 32px',
                    background: 'var(--gold)',
                    color: 'var(--ink)',
                    border: 'none',
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: '2.5px',
                    textTransform: 'uppercase',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.background =
                      'var(--gold-dark)';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.background = 'var(--gold)';
                  }}
                >
                  Proceed to Checkout
                </button>
                <button
                  onClick={clearCart}
                  style={{
                    padding: '16px 32px',
                    background: 'transparent',
                    color: 'var(--warm-grey)',
                    border: '1px solid var(--muted)',
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: '2.5px',
                    textTransform: 'uppercase',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = '#c44';
                    (e.currentTarget as HTMLElement).style.color = '#c44';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = 'var(--muted)';
                    (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
                  }}
                >
                  Clear Cart
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Empty Cart */
          <div
            className="cart-fade-in"
            style={{
              textAlign: 'center',
              padding: '80px 0',
            }}
          >
            <div
              style={{
                width: '80px',
                height: '80px',
                borderRadius: '50%',
                border: '1px solid var(--muted)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 24px',
              }}
            >
              <Package size={32} strokeWidth={1} color="var(--muted)" />
            </div>
            <h3
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 400,
                fontSize: '24px',
                color: 'var(--ink)',
                marginBottom: '12px',
              }}
            >
              Your cart is empty
            </h3>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '14px',
                color: 'var(--warm-grey)',
                marginBottom: '32px',
                maxWidth: '400px',
                marginInline: 'auto',
                lineHeight: 1.6,
              }}
            >
              Explore our collections and find something you'll love.
            </p>
            <Link
              to="/search"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '15px 40px',
                background: 'var(--gold)',
                color: 'var(--ink)',
                textDecoration: 'none',
                fontFamily: "'Inter', sans-serif",
                fontWeight: 600,
                fontSize: '11px',
                letterSpacing: '2.5px',
                textTransform: 'uppercase',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'var(--gold-dark)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'var(--gold)';
              }}
            >
              <ShoppingBag size={16} strokeWidth={1.5} />
              Browse Products
            </Link>
          </div>
        )}
      </div>

      <Footer />

      <style>{`
        @media (max-width: 768px) {
          .cart-item {
            grid-template-columns: 80px 1fr !important;
            grid-template-rows: auto auto;
          }
        }
      `}</style>
    </div>
  );
}
