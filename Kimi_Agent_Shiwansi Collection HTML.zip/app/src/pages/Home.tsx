import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  ChevronDown,
  Award,
  Heart,
  Leaf,
  Store,
  Package,
  Truck,
  Rainbow,
  Star,
  MapPin,
  Clock,
  Phone,
  Hash,
  Venus,
} from 'lucide-react';
import Footer from '../components/Footer';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const heroBgRef = useRef<HTMLDivElement>(null);
  const heroContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Wait for images to load before creating ScrollTriggers
    const images = document.querySelectorAll('img');
    let loadedCount = 0;
    const totalImages = images.length;

    const onAllLoaded = () => {
      ScrollTrigger.refresh();
    };

    if (totalImages === 0) {
      onAllLoaded();
    } else {
      images.forEach((img) => {
        if (img.complete) {
          loadedCount++;
          if (loadedCount === totalImages) onAllLoaded();
        } else {
          img.addEventListener('load', () => {
            loadedCount++;
            if (loadedCount === totalImages) onAllLoaded();
          });
        }
      });
    }

    // Hero parallax
    if (heroRef.current && heroBgRef.current) {
      gsap.to(heroBgRef.current, {
        y: '-30%',
        ease: 'none',
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }

    if (heroContentRef.current) {
      gsap.to(heroContentRef.current, {
        y: -80,
        opacity: 0,
        ease: 'none',
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: '50% top',
          scrub: true,
        },
      });
    }

    // Reveal animations
    const revealElements = document.querySelectorAll('.reveal-item');
    revealElements.forEach((el) => {
      gsap.fromTo(
        el,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    });

    // Collection cards curtain reveal
    const cards = document.querySelectorAll('.collection-card');
    cards.forEach((card, i) => {
      const mask = card.querySelector('.curtain-mask') as HTMLElement;
      const imgWrap = card.querySelector('.curtain-image-wrap') as HTMLElement;

      if (mask && imgWrap) {
        gsap.fromTo(
          imgWrap,
          { scaleX: 0 },
          {
            scaleX: 1,
            duration: 1.2,
            ease: 'power4.inOut',
            delay: i * 0.2,
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
        gsap.fromTo(
          mask,
          { scaleX: 1 },
          {
            scaleX: 0,
            duration: 1.2,
            ease: 'power4.inOut',
            delay: i * 0.2,
            transformOrigin: 'right',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
            onComplete: () => {
              if (mask) mask.style.display = 'none';
            },
          }
        );
      }
    });

    // About section parallax images
    const aboutMain = document.querySelector('.about-main-img') as HTMLElement;
    const aboutFloat = document.querySelector('.about-float-img') as HTMLElement;
    const aboutSection = document.querySelector('.about-section') as HTMLElement;

    if (aboutSection && aboutMain) {
      gsap.to(aboutMain, {
        y: -60,
        ease: 'none',
        scrollTrigger: {
          trigger: aboutSection,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        },
      });
    }

    if (aboutSection && aboutFloat) {
      gsap.to(aboutFloat, {
        y: -120,
        ease: 'none',
        scrollTrigger: {
          trigger: aboutSection,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        },
      });
    }

    // About heading line reveal
    const aboutLines = document.querySelectorAll('.about-line-inner');
    aboutLines.forEach((line, i) => {
      gsap.fromTo(
        line,
        { y: '100%', opacity: 0 },
        {
          y: '0%',
          opacity: 1,
          duration: 0.9,
          ease: 'expo.out',
          delay: i * 0.08,
          scrollTrigger: {
            trigger: '.about-heading',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    });

    // Service cards stagger
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, i) => {
      gsap.fromTo(
        card,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          ease: 'power3.out',
          delay: i * 0.12,
          scrollTrigger: {
            trigger: '.services-grid',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    });

    // Visit section slide-in
    const visitInfo = document.querySelector('.visit-info') as HTMLElement;
    const visitMap = document.querySelector('.visit-map') as HTMLElement;

    if (visitInfo) {
      gsap.fromTo(
        visitInfo,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.visit-section',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }

    if (visitMap) {
      gsap.fromTo(
        visitMap,
        { x: 60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.visit-section',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }

    return () => {
      ScrollTrigger.getAll().forEach((t: ScrollTrigger) => t.kill());
    };
  }, []);

  const scrollToCollections = () => {
    const el = document.getElementById('collections');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero Section */}
      <section
        ref={heroRef}
        style={{
          height: '100vh',
          position: 'relative',
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          ref={heroBgRef}
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `linear-gradient(to bottom, rgba(45,41,38,0.35), rgba(45,41,38,0.55)), url('/images/hero_bg.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            transform: 'scale(1.15)',
            willChange: 'transform',
          }}
        />
        <div
          ref={heroContentRef}
          style={{
            position: 'relative',
            zIndex: 2,
            textAlign: 'center',
            maxWidth: '680px',
            padding: '0 20px',
            color: 'var(--warm-white)',
          }}
        >
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '10px',
              letterSpacing: '3px',
              textTransform: 'uppercase',
              color: 'rgba(247,245,242,0.8)',
              marginBottom: '25px',
              opacity: 0,
              animation: 'fadeInUp 1s ease forwards 0.5s',
            }}
          >
            Est. Itahari — Nepal
          </div>
          <h1
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300,
              fontSize: 'clamp(3rem, 8vw, 4.5rem)',
              lineHeight: 1.05,
              letterSpacing: '-1.8px',
              marginBottom: '20px',
              opacity: 0,
              animation: 'fadeInUp 1s ease forwards 0.8s',
            }}
          >
            Style for{' '}
            <em style={{ fontStyle: 'italic', fontWeight: 400, color: 'var(--gold)' }}>
              Every
            </em>
            <br />
            Generation
          </h1>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 400,
              fontSize: '16px',
              lineHeight: 1.7,
              color: 'rgba(247,245,242,0.85)',
              marginBottom: '40px',
              opacity: 0,
              animation: 'fadeInUp 1s ease forwards 1.1s',
            }}
          >
            Curated men's, women's &amp; baby wear in the heart of Itahari.
            Where tradition meets contemporary fashion.
          </p>
          <div
            style={{
              display: 'flex',
              gap: '20px',
              justifyContent: 'center',
              flexWrap: 'wrap',
              opacity: 0,
              animation: 'fadeInUp 1s ease forwards 1.4s',
            }}
          >
            <a
              href="#collections"
              onClick={(e) => {
                e.preventDefault();
                scrollToCollections();
              }}
              style={{
                background: 'var(--gold)',
                color: 'var(--ink)',
                padding: '15px 40px',
                textDecoration: 'none',
                fontFamily: "'Inter', sans-serif",
                fontWeight: 600,
                fontSize: '11px',
                letterSpacing: '2.5px',
                textTransform: 'uppercase',
                transition: 'all 0.4s ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'var(--gold-dark)';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'var(--gold)';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
              }}
            >
              Explore Collection
            </a>
            <a
              href="#visit"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('visit')?.scrollIntoView({ behavior: 'smooth' });
              }}
              style={{
                background: 'transparent',
                color: 'var(--warm-white)',
                border: '1px solid var(--warm-white)',
                padding: '15px 40px',
                textDecoration: 'none',
                fontFamily: "'Inter', sans-serif",
                fontWeight: 600,
                fontSize: '11px',
                letterSpacing: '2.5px',
                textTransform: 'uppercase',
                transition: 'all 0.4s ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'var(--warm-white)';
                (e.currentTarget as HTMLElement).style.color = 'var(--ink)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = 'transparent';
                (e.currentTarget as HTMLElement).style.color = 'var(--warm-white)';
              }}
            >
              Find Store
            </a>
          </div>
        </div>

        {/* Scroll indicator */}
        <button
          onClick={scrollToCollections}
          style={{
            position: 'absolute',
            bottom: '40px',
            left: '50%',
            color: 'var(--warm-white)',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            zIndex: 2,
            animation: 'bounce 2s infinite',
          }}
        >
          <ChevronDown size={24} strokeWidth={1.5} />
        </button>
      </section>

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      {/* Collections Section */}
      <CollectionsSection />

      {/* About Section */}
      <AboutSection />

      {/* Services Section */}
      <ServicesSection />

      {/* Marquee */}
      <MarqueeSection />

      {/* Testimonials */}
      <TestimonialsSection />

      {/* Visit Us */}
      <VisitSection />

      {/* Footer */}
      <Footer />
    </div>
  );
}

/* ======================= SUB-COMPONENTS ======================= */

function CollectionsSection() {
  const collections = [
    {
      title: "Men's Wear",
      subtitle: 'Sharp Suits & Casual Elegance',
      image: '/images/collection_mens.jpg',
      height: '520px',
    },
    {
      title: "Women's Wear",
      subtitle: 'Timeless Grace & Modern Chic',
      image: '/images/collection_womens.jpg',
      height: '600px',
      offset: '120px',
    },
    {
      title: 'Baby Wear',
      subtitle: 'Soft Comfort & Adorable Style',
      image: '/images/collection_baby.jpg',
      height: '480px',
    },
  ];

  return (
    <section
      id="collections"
      style={{ padding: '140px 48px', background: 'var(--warm-white)' }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="reveal-item" style={{ textAlign: 'center', marginBottom: '60px' }}>
          <h2
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300,
              fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
              letterSpacing: '-1.2px',
              color: 'var(--ink)',
              marginBottom: '15px',
              position: 'relative',
              display: 'inline-block',
            }}
          >
            Our Collections
            <span
              style={{
                content: "''",
                position: 'absolute',
                bottom: '-10px',
                left: '50%',
                transform: 'translateX(-50%)',
                width: '60px',
                height: '2px',
                background: 'var(--gold)',
              }}
            />
          </h2>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '15px',
              color: 'var(--warm-grey)',
              marginTop: '25px',
              maxWidth: '600px',
              marginInline: 'auto',
              lineHeight: 1.7,
            }}
          >
            Thoughtfully curated for the modern family. Discover pieces that
            speak to your personal style.
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '24px',
          }}
          className="collection-grid"
        >
          {collections.map((col) => (
            <div
              key={col.title}
              className="collection-card reveal-item"
              style={{
                position: 'relative',
                height: col.height,
                overflow: 'hidden',
                cursor: 'pointer',
                marginTop: col.offset || 0,
              }}
            >
              <div
                className="curtain-image-wrap"
                style={{
                  position: 'absolute',
                  inset: 0,
                  transformOrigin: 'left',
                }}
              >
                <img
                  src={col.image}
                  alt={col.title}
                  className="collection-card-image"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                  }}
                />
              </div>
              <div
                className="curtain-mask"
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'var(--gold)',
                  zIndex: 2,
                  transformOrigin: 'right',
                }}
              />
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background:
                    'linear-gradient(to top, rgba(45,41,38,0.7) 0%, rgba(45,41,38,0.1) 50%, transparent 100%)',
                  zIndex: 3,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'flex-end',
                  padding: '40px',
                }}
              >
                <h3
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontWeight: 400,
                    fontSize: '28px',
                    color: 'var(--warm-white)',
                    marginBottom: '8px',
                    letterSpacing: '-0.3px',
                  }}
                >
                  {col.title}
                </h3>
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontWeight: 500,
                    fontSize: '10px',
                    letterSpacing: '2px',
                    textTransform: 'uppercase',
                    color: 'rgba(247,245,242,0.7)',
                  }}
                >
                  {col.subtitle}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .collection-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}

function AboutSection() {
  const features = [
    { icon: Award, title: 'Premium Quality', subtitle: 'Handpicked Fabrics' },
    { icon: Heart, title: 'Family First', subtitle: 'All Ages Welcome' },
    { icon: Leaf, title: 'Ethical Choice', subtitle: 'Sustainable Fashion' },
  ];

  return (
    <section
      id="about"
      className="about-section"
      style={{
        padding: '140px 48px',
        background: 'var(--warm-white)',
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '80px',
        alignItems: 'center',
      }}
    >
      {/* Left - Images */}
      <div style={{ position: 'relative' }} className="about-images">
        <img
          src="/images/about_main.jpg"
          alt="Shiwansi Store Interior"
          className="about-main-img reveal-item"
          style={{
            width: '100%',
            height: '560px',
            objectFit: 'cover',
            boxShadow: '30px 30px 0 var(--gold)',
          }}
        />
        <img
          src="/images/about_float.jpg"
          alt="Fashion Detail"
          className="about-float-img reveal-item"
          style={{
            position: 'absolute',
            bottom: '-40px',
            right: '-40px',
            width: '260px',
            height: '340px',
            objectFit: 'cover',
            border: '10px solid var(--warm-white)',
            boxShadow: '0 20px 50px rgba(45,41,38,0.1)',
          }}
        />
      </div>

      {/* Right - Content */}
      <div>
        <div className="about-heading">
          <div className="line-mask">
            <span
              className="about-line-inner"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 300,
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                letterSpacing: '-1.2px',
                lineHeight: 1.2,
                color: 'var(--ink)',
              }}
            >
              Crafting Style in
            </span>
          </div>
          <div className="line-mask">
            <span
              className="about-line-inner"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 300,
                fontStyle: 'italic',
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                letterSpacing: '-1.2px',
                lineHeight: 1.2,
                color: 'var(--gold)',
              }}
            >
              Itahari
            </span>
          </div>
        </div>

        <p
          className="reveal-item"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '15px',
            lineHeight: 1.9,
            color: 'var(--warm-grey)',
            marginTop: '30px',
            marginBottom: '25px',
          }}
        >
          Shiwansi Collection is more than a clothing store — it's a destination
          for families who value quality, comfort, and expression. Located on
          Laligurans Marg in Jutebikash, we bring together the finest selections
          for men, women, and little ones.
        </p>
        <p
          className="reveal-item"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '15px',
            lineHeight: 1.9,
            color: 'var(--warm-grey)',
            marginBottom: '40px',
          }}
        >
          As a proud women-owned business, we believe in empowering through
          fashion. Every piece in our collection is chosen with care, ensuring
          that you don't just wear clothes — you wear confidence.
        </p>

        <div
          style={{ display: 'flex', gap: '40px' }}
          className="reveal-item about-features"
        >
          {features.map((f) => (
            <div key={f.title} style={{ textAlign: 'center' }}>
              <f.icon
                size={24}
                style={{ color: 'var(--gold)', marginBottom: '15px' }}
                strokeWidth={1.5}
              />
              <h4
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontWeight: 400,
                  fontSize: '18px',
                  color: 'var(--ink)',
                  marginBottom: '5px',
                }}
              >
                {f.title}
              </h4>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '12px',
                  color: 'var(--warm-grey)',
                }}
              >
                {f.subtitle}
              </span>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 1024px) {
          .about-section {
            grid-template-columns: 1fr !important;
            gap: 48px !important;
          }
          .about-images {
            order: -1;
          }
          .about-float-img {
            display: none !important;
          }
        }
        @media (max-width: 768px) {
          .about-section {
            padding: 80px 30px !important;
          }
          .about-features {
            flex-direction: column;
            gap: 24px !important;
          }
        }
      `}</style>
    </section>
  );
}

function ServicesSection() {
  const services = [
    {
      icon: Store,
      title: 'In-Store Shopping',
      desc: 'Experience our collections firsthand in our beautifully designed boutique space on Laligurans Marg.',
    },
    {
      icon: Package,
      title: 'In-Store Pick-up',
      desc: 'Order ahead and collect your selections at your convenience. Fast, easy, and hassle-free.',
    },
    {
      icon: Truck,
      title: 'Home Delivery',
      desc: 'We bring fashion to your doorstep. Reliable delivery service across Itahari and surrounding areas.',
    },
    {
      icon: Rainbow,
      title: 'LGBTQ+ Friendly',
      desc: 'An inclusive, welcoming space for everyone. Express yourself freely and authentically with us.',
    },
  ];

  return (
    <section
      id="services"
      style={{
        padding: '100px 48px',
        background: 'var(--ink)',
        color: 'var(--warm-white)',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="reveal-item" style={{ textAlign: 'center', marginBottom: '60px' }}>
          <h2
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300,
              fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
              letterSpacing: '-1.2px',
              color: 'var(--warm-white)',
              marginBottom: '15px',
            }}
          >
            Our Services
          </h2>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '15px',
              color: 'rgba(247,245,242,0.6)',
              maxWidth: '600px',
              marginInline: 'auto',
              lineHeight: 1.7,
            }}
          >
            We go beyond retail to offer a complete fashion experience.
          </p>
        </div>

        <div
          className="services-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: '24px',
          }}
        >
          {services.map((s) => (
            <div
              key={s.title}
              className="service-card reveal-item"
              style={{
                textAlign: 'center',
                padding: '48px 32px',
                border: '1px solid rgba(247,245,242,0.08)',
              }}
            >
              <s.icon
                size={32}
                style={{ color: 'var(--gold)', marginBottom: '25px' }}
                strokeWidth={1.5}
              />
              <h3
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontWeight: 400,
                  fontSize: '22px',
                  marginBottom: '15px',
                  color: 'var(--warm-white)',
                }}
              >
                {s.title}
              </h3>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '14px',
                  color: 'rgba(247,245,242,0.55)',
                  lineHeight: 1.7,
                }}
              >
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 1024px) {
          .services-grid {
            grid-template-columns: repeat(2, 1fr) !important;
          }
        }
        @media (max-width: 768px) {
          .services-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}

function MarqueeSection() {
  const text = 'SHIWANSI COLLECTION — ITAHARI — STYLE FOR EVERY GENERATION — ';

  return (
    <section
      style={{
        background: 'var(--gold)',
        overflow: 'hidden',
        padding: '20px 0',
      }}
    >
      <div className="marquee-track">
        <span
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 300,
            fontSize: '48px',
            color: 'var(--ink)',
            whiteSpace: 'nowrap',
          }}
        >
          {text}
          {text}
        </span>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  const testimonials = [
    {
      quote:
        "Absolutely love the variety here! Found the perfect outfit for my brother's wedding and adorable dresses for my niece. The quality is unmatched in Itahari.",
      name: 'Priya Sharma',
      role: 'Regular Customer',
      image: '/images/testimonial_1.jpg',
    },
    {
      quote:
        'A welcoming space with incredible style. As a women-owned business, they truly understand what modern families need. The delivery service is prompt too!',
      name: 'Rajesh Gupta',
      role: 'Verified Buyer',
      image: '/images/testimonial_2.jpg',
    },
  ];

  return (
    <section style={{ padding: '140px 48px', background: 'var(--warm-white)' }}>
      <div style={{ maxWidth: '960px', margin: '0 auto' }}>
        <div className="reveal-item" style={{ textAlign: 'center', marginBottom: '60px' }}>
          <h2
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300,
              fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
              letterSpacing: '-1.2px',
              color: 'var(--ink)',
              marginBottom: '15px',
            }}
          >
            Client Love
          </h2>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '15px',
              color: 'var(--warm-grey)',
              lineHeight: 1.7,
            }}
          >
            What our community says about Shiwansi Collection.
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '40px',
          }}
          className="testimonial-grid"
        >
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="reveal-item"
              style={{
                background: 'var(--cream)',
                padding: '48px',
                position: 'relative',
              }}
            >
              <span
                style={{
                  position: 'absolute',
                  top: '20px',
                  left: '30px',
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '120px',
                  color: 'var(--gold)',
                  opacity: 0.15,
                  lineHeight: 1,
                  pointerEvents: 'none',
                }}
              >
                &ldquo;
              </span>
              <div style={{ marginBottom: '20px' }}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    fill="var(--gold)"
                    color="var(--gold)"
                    style={{ display: 'inline' }}
                  />
                ))}
              </div>
              <p
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: 'italic',
                  fontSize: '20px',
                  lineHeight: 1.55,
                  color: 'rgba(45,41,38,0.7)',
                  marginBottom: '25px',
                }}
              >
                {t.quote}
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <img
                  src={t.image}
                  alt={t.name}
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    objectFit: 'cover',
                  }}
                />
                <div>
                  <h4
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontWeight: 600,
                      fontSize: '14px',
                      color: 'var(--ink)',
                    }}
                  >
                    {t.name}
                  </h4>
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '12px',
                      color: 'var(--warm-grey)',
                    }}
                  >
                    {t.role}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .testimonial-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </section>
  );
}

function VisitSection() {
  const infoItems = [
    {
      icon: MapPin,
      label: 'Address',
      value: 'Jutebikash, Laligurans Marg\nItahari 56705, Nepal',
    },
    {
      icon: Clock,
      label: 'Opening Hours',
      value: 'Open now · Closes 5 PM\nSunday — Saturday: 9:00 AM — 5:00 PM',
    },
    {
      icon: Phone,
      label: 'Contact',
      value: '981-9047099',
      isLink: true,
      href: 'tel:+9779819047099',
    },
    {
      icon: Hash,
      label: 'Plus Code',
      value: 'M75M+6G Itahari',
    },
  ];

  const badges = [
    { icon: Venus, label: 'Women-Owned' },
    { icon: Rainbow, label: 'LGBTQ+ Friendly' },
    { icon: Star, label: '5.0 Rating' },
  ];

  return (
    <section
      id="visit"
      className="visit-section"
      style={{
        padding: '140px 48px',
        background: 'var(--warm-white)',
      }}
    >
      <div
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 0,
        }}
        className="visit-grid"
      >
        {/* Left - Info */}
        <div
          className="visit-info"
          style={{
            padding: '60px',
            background: 'var(--warm-white)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
          }}
        >
          <h2 style={{ marginBottom: '30px' }}>
            <span
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 300,
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                letterSpacing: '-1.2px',
                color: 'var(--ink)',
                display: 'block',
              }}
            >
              Visit
            </span>
            <span
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 300,
                fontStyle: 'italic',
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                letterSpacing: '-1.2px',
                color: 'var(--gold)',
              }}
            >
              Us
            </span>
          </h2>

          {infoItems.map((item) => (
            <div
              key={item.label}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '20px',
                marginBottom: '30px',
              }}
            >
              <item.icon
                size={20}
                style={{
                  color: 'var(--gold)',
                  marginTop: '3px',
                  flexShrink: 0,
                }}
                strokeWidth={1.5}
              />
              <div>
                <h4
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontWeight: 600,
                    fontSize: '14px',
                    color: 'var(--ink)',
                    marginBottom: '5px',
                  }}
                >
                  {item.label}
                </h4>
                {item.isLink ? (
                  <a
                    href={item.href}
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: 'var(--warm-grey)',
                      textDecoration: 'none',
                      lineHeight: 1.6,
                      transition: 'color 0.3s',
                      whiteSpace: 'pre-line',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
                    }}
                  >
                    {item.value}
                  </a>
                ) : (
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: 'var(--warm-grey)',
                      lineHeight: 1.6,
                      whiteSpace: 'pre-line',
                      margin: 0,
                    }}
                  >
                    {item.value}
                  </p>
                )}
              </div>
            </div>
          ))}

          <div
            style={{
              marginTop: '30px',
              display: 'flex',
              gap: '10px',
              flexWrap: 'wrap',
            }}
          >
            {badges.map((b) => (
              <span key={b.label} className="badge">
                <b.icon size={12} />
                {b.label}
              </span>
            ))}
          </div>
        </div>

        {/* Right - Map */}
        <div
          className="visit-map"
          style={{
            background: 'var(--ink)',
            minHeight: '520px',
            position: 'relative',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3571.55884792989!2d87.2833!3d26.6667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDQwJzAwLjAiTiA4N8KwMTcnMDAuMCJF!5e0!3m2!1sen!2snp!4v1600000000000!5m2!1sen!2snp"
            allowFullScreen
            loading="lazy"
            style={{
              width: '100%',
              height: '100%',
              position: 'absolute',
              inset: 0,
              border: 'none',
              filter: 'grayscale(100%) contrast(1.2)',
            }}
          />
          <div
            style={{
              position: 'relative',
              zIndex: 2,
              textAlign: 'center',
              color: 'var(--warm-white)',
              background: 'rgba(45,41,38,0.7)',
              padding: '40px',
              backdropFilter: 'blur(10px)',
            }}
          >
            <h3
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 400,
                fontSize: '24px',
                marginBottom: '8px',
              }}
            >
              Shiwansi Collection
            </h3>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '14px',
                opacity: 0.8,
              }}
            >
              Jutebikash, Itahari
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 1024px) {
          .visit-grid {
            grid-template-columns: 1fr !important;
          }
        }
        @media (max-width: 768px) {
          .visit-section {
            padding: 80px 30px !important;
          }
          .visit-info {
            padding: 40px 30px !important;
          }
        }
      `}</style>
    </section>
  );
}
