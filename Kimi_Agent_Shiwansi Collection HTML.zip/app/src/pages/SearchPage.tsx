import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Search, ArrowLeft, ShoppingBag, Filter } from 'lucide-react';
import gsap from 'gsap';
import { products } from '../data/products';
import { useCartStore } from '../store/cartStore';
import Footer from '../components/Footer';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('all');
  const addItem = useCartStore((s) => s.addItem);
  const [addedId, setAddedId] = useState<string | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const filtered = products.filter((p) => {
    const matchesQuery =
      !query ||
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = category === 'all' || p.category === category;
    return matchesQuery && matchesCategory;
  });

  const handleAdd = (product: (typeof products)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    });
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    gsap.fromTo(
      '.search-fade-in',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', stagger: 0.1 }
    );
  }, []);

  useEffect(() => {
    if (resultsRef.current) {
      gsap.fromTo(
        resultsRef.current.children,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, ease: 'power3.out', stagger: 0.06 }
      );
    }
  }, [query, category]);

  const categories = [
    { value: 'all', label: 'All' },
    { value: 'mens', label: "Men's" },
    { value: 'womens', label: "Women's" },
    { value: 'baby', label: 'Baby' },
  ];

  const formatPrice = (p: number) => `Rs. ${p.toLocaleString()}`;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--warm-white)' }}>
      {/* Header */}
      <div style={{ padding: '120px 48px 40px', maxWidth: '1200px', margin: '0 auto' }}>
        <Link
          to="/"
          className="search-fade-in"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            color: 'var(--warm-grey)',
            textDecoration: 'none',
            fontFamily: "'Inter', sans-serif",
            fontSize: '13px',
            letterSpacing: '1px',
            textTransform: 'uppercase',
            marginBottom: '40px',
            transition: 'color 0.3s',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
          }}
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          Back to Home
        </Link>

        <h1
          className="search-fade-in"
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 300,
            fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
            letterSpacing: '-1.2px',
            color: 'var(--ink)',
            marginBottom: '40px',
          }}
        >
          Search
        </h1>

        {/* Search Input */}
        <div
          className="search-fade-in"
          style={{
            position: 'relative',
            maxWidth: '600px',
            marginBottom: '30px',
          }}
        >
          <Search
            size={18}
            style={{
              position: 'absolute',
              left: '20px',
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'var(--warm-grey)',
            }}
            strokeWidth={1.5}
          />
          <input
            type="text"
            placeholder="Search for products..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '18px 18px 18px 52px',
              fontFamily: "'Inter', sans-serif",
              fontSize: '15px',
              color: 'var(--ink)',
              background: 'var(--warm-white)',
              border: '1px solid var(--muted)',
              outline: 'none',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = 'var(--gold)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = 'var(--muted)';
            }}
          />
        </div>

        {/* Category Filters */}
        <div
          className="search-fade-in"
          style={{ display: 'flex', gap: '10px', marginBottom: '40px', flexWrap: 'wrap' }}
        >
          <Filter
            size={16}
            style={{ color: 'var(--warm-grey)', marginRight: '4px', alignSelf: 'center' }}
            strokeWidth={1.5}
          />
          {categories.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value)}
              style={{
                padding: '8px 20px',
                fontFamily: "'Inter', sans-serif",
                fontSize: '11px',
                fontWeight: 600,
                letterSpacing: '1.5px',
                textTransform: 'uppercase',
                border:
                  category === c.value
                    ? '1px solid var(--gold)'
                    : '1px solid var(--muted)',
                background: category === c.value ? 'var(--gold)' : 'transparent',
                color: category === c.value ? 'var(--ink)' : 'var(--warm-grey)',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
              }}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Results count */}
        <p
          className="search-fade-in"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '13px',
            color: 'var(--warm-grey)',
            marginBottom: '30px',
          }}
        >
          {filtered.length} product{filtered.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Product Grid */}
      <div
        style={{
          padding: '0 48px 100px',
          maxWidth: '1200px',
          margin: '0 auto',
        }}
      >
        {filtered.length > 0 ? (
          <div
            ref={resultsRef}
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '32px',
            }}
            className="search-results-grid"
          >
            {filtered.map((product) => (
              <div
                key={product.id}
                style={{
                  background: 'var(--warm-white)',
                  border: '1px solid var(--muted)',
                  overflow: 'hidden',
                  transition: 'box-shadow 0.3s',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.boxShadow =
                    '0 16px 40px rgba(45,41,38,0.08)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.boxShadow = 'none';
                }}
              >
                <div
                  style={{
                    height: '280px',
                    overflow: 'hidden',
                    position: 'relative',
                  }}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      transition: 'transform 0.6s ease',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = 'scale(1.05)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.transform = 'scale(1)';
                    }}
                  />
                  <span
                    style={{
                      position: 'absolute',
                      top: '12px',
                      left: '12px',
                      background: 'var(--ink)',
                      color: 'var(--warm-white)',
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '9px',
                      fontWeight: 600,
                      letterSpacing: '1.5px',
                      textTransform: 'uppercase',
                      padding: '4px 10px',
                    }}
                  >
                    {product.category}
                  </span>
                </div>
                <div style={{ padding: '24px' }}>
                  <h3
                    style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontWeight: 400,
                      fontSize: '20px',
                      color: 'var(--ink)',
                      marginBottom: '8px',
                      letterSpacing: '-0.3px',
                    }}
                  >
                    {product.name}
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '13px',
                      color: 'var(--warm-grey)',
                      lineHeight: 1.6,
                      marginBottom: '16px',
                    }}
                  >
                    {product.description}
                  </p>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontWeight: 600,
                        fontSize: '22px',
                        color: 'var(--gold)',
                      }}
                    >
                      {formatPrice(product.price)}
                    </span>
                    <button
                      onClick={() => handleAdd(product)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '10px 20px',
                        background:
                          addedId === product.id ? 'var(--gold)' : 'var(--ink)',
                        color: 'var(--warm-white)',
                        border: 'none',
                        fontFamily: "'Inter', sans-serif",
                        fontSize: '10px',
                        fontWeight: 600,
                        letterSpacing: '1.5px',
                        textTransform: 'uppercase',
                        cursor: 'pointer',
                        transition: 'all 0.3s ease',
                      }}
                    >
                      <ShoppingBag size={14} strokeWidth={1.5} />
                      {addedId === product.id ? 'Added!' : 'Add to Cart'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '80px 0' }}>
            <Search
              size={48}
              style={{ color: 'var(--muted)', marginBottom: '20px' }}
              strokeWidth={1}
            />
            <h3
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 400,
                fontSize: '24px',
                color: 'var(--ink)',
                marginBottom: '8px',
              }}
            >
              No products found
            </h3>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '14px',
                color: 'var(--warm-grey)',
              }}
            >
              Try adjusting your search or filter criteria.
            </p>
          </div>
        )}
      </div>

      <Footer />

      <style>{`
        @media (max-width: 1024px) {
          .search-results-grid {
            grid-template-columns: repeat(2, 1fr) !important;
          }
        }
        @media (max-width: 768px) {
          .search-results-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
