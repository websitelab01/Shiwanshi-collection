import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  User,
  MapPin,
  Phone,
  Mail,
  Clock,
  ShoppingBag,
  Heart,
  Settings,
  LogOut,
  ChevronRight,
} from 'lucide-react';
import gsap from 'gsap';
import Footer from '../components/Footer';

interface Order {
  id: string;
  date: string;
  items: string[];
  total: number;
  status: 'delivered' | 'processing' | 'shipped';
}

const mockOrders: Order[] = [
  {
    id: 'ORD-2025-001',
    date: 'Feb 12, 2025',
    items: ['Classic Navy Blazer', 'Linen Summer Shirt'],
    total: 11300,
    status: 'delivered',
  },
  {
    id: 'ORD-2025-002',
    date: 'Mar 3, 2025',
    items: ['Silk Evening Gown'],
    total: 15000,
    status: 'shipped',
  },
  {
    id: 'ORD-2025-003',
    date: 'Mar 28, 2025',
    items: ['Organic Cotton Onesie', 'Baby Festive Set'],
    total: 4000,
    status: 'processing',
  },
];

const statusColors: Record<string, string> = {
  delivered: 'var(--gold)',
  shipped: '#4a90d9',
  processing: 'var(--warm-grey)',
};

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<'orders' | 'saved' | 'settings'>('orders');

  useEffect(() => {
    window.scrollTo(0, 0);
    gsap.fromTo(
      '.profile-fade-in',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', stagger: 0.1 }
    );
  }, []);

  const formatPrice = (p: number) => `Rs. ${p.toLocaleString()}`;

  const menuItems = [
    { id: 'orders', label: 'My Orders', icon: ShoppingBag },
    { id: 'saved', label: 'Saved Items', icon: Heart },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--warm-white)' }}>
      <div
        style={{
          padding: '120px 48px 40px',
          maxWidth: '1000px',
          margin: '0 auto',
        }}
      >
        <Link
          to="/"
          className="profile-fade-in"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            color: 'var(--warm-grey)',
            textDecoration: 'none',
            fontFamily: "'Inter', sans-serif",
            fontSize: '13px',
            letterSpacing: '1px',
            textTransform: 'uppercase',
            marginBottom: '40px',
            transition: 'color 0.3s',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
          }}
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          Back to Home
        </Link>

        <h1
          className="profile-fade-in"
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 300,
            fontSize: 'clamp(2.5rem, 5vw, 3.5rem)',
            letterSpacing: '-1.2px',
            color: 'var(--ink)',
            marginBottom: '40px',
          }}
        >
          My Profile
        </h1>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '280px 1fr',
            gap: '48px',
            alignItems: 'start',
          }}
          className="profile-layout"
        >
          {/* Sidebar */}
          <div className="profile-fade-in">
            {/* Profile Card */}
            <div
              style={{
                background: 'var(--cream)',
                padding: '32px',
                textAlign: 'center',
                marginBottom: '24px',
              }}
            >
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  background: 'var(--gold)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 16px',
                }}
              >
                <User size={32} color="var(--ink)" strokeWidth={1.5} />
              </div>
              <h2
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontWeight: 400,
                  fontSize: '22px',
                  color: 'var(--ink)',
                  marginBottom: '4px',
                }}
              >
                Priya Sharma
              </h2>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '12px',
                  color: 'var(--warm-grey)',
                  letterSpacing: '1px',
                  textTransform: 'uppercase',
                }}
              >
                Regular Customer
              </p>

              <div
                style={{
                  marginTop: '20px',
                  paddingTop: '20px',
                  borderTop: '1px solid var(--muted)',
                  textAlign: 'left',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    marginBottom: '10px',
                  }}
                >
                  <MapPin size={14} color="var(--gold)" strokeWidth={1.5} />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '12px',
                      color: 'var(--warm-grey)',
                    }}
                  >
                    Itahari, Nepal
                  </span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    marginBottom: '10px',
                  }}
                >
                  <Phone size={14} color="var(--gold)" strokeWidth={1.5} />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '12px',
                      color: 'var(--warm-grey)',
                    }}
                  >
                    981-9047099
                  </span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                >
                  <Mail size={14} color="var(--gold)" strokeWidth={1.5} />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '12px',
                      color: 'var(--warm-grey)',
                    }}
                  >
                    priya@email.com
                  </span>
                </div>
              </div>
            </div>

            {/* Menu */}
            <div style={{ background: 'var(--cream)' }}>
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '16px 24px',
                    background: activeTab === item.id ? 'var(--gold)' : 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '13px',
                    fontWeight: 500,
                    letterSpacing: '1px',
                    textTransform: 'uppercase',
                    color: activeTab === item.id ? 'var(--ink)' : 'var(--warm-grey)',
                    transition: 'all 0.3s ease',
                    textAlign: 'left',
                  }}
                >
                  <item.icon size={16} strokeWidth={1.5} />
                  {item.label}
                </button>
              ))}
              <div style={{ borderTop: '1px solid var(--muted)' }}>
                <button
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '16px 24px',
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    fontFamily: "'Inter', sans-serif",
                    fontSize: '13px',
                    fontWeight: 500,
                    letterSpacing: '1px',
                    textTransform: 'uppercase',
                    color: 'var(--warm-grey)',
                    transition: 'color 0.3s',
                    textAlign: 'left',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = '#c44';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
                  }}
                >
                  <LogOut size={16} strokeWidth={1.5} />
                  Sign Out
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="profile-fade-in">
            {activeTab === 'orders' && (
              <div>
                <h2
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontWeight: 400,
                    fontSize: '28px',
                    color: 'var(--ink)',
                    marginBottom: '24px',
                  }}
                >
                  Order History
                </h2>

                {mockOrders.map((order) => (
                  <div
                    key={order.id}
                    style={{
                      background: 'var(--cream)',
                      padding: '28px',
                      marginBottom: '16px',
                      transition: 'box-shadow 0.3s',
                      cursor: 'pointer',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.boxShadow =
                        '0 8px 24px rgba(45,41,38,0.06)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.boxShadow = 'none';
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-start',
                        marginBottom: '12px',
                      }}
                    >
                      <div>
                        <span
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontSize: '10px',
                            fontWeight: 600,
                            letterSpacing: '1.5px',
                            textTransform: 'uppercase',
                            color: 'var(--gold)',
                          }}
                        >
                          {order.id}
                        </span>
                        <h3
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontWeight: 500,
                            fontSize: '15px',
                            color: 'var(--ink)',
                            marginTop: '4px',
                          }}
                        >
                          {order.items.join(', ')}
                        </h3>
                      </div>
                      <span
                        style={{
                          fontFamily: "'Inter', sans-serif",
                          fontSize: '11px',
                          fontWeight: 600,
                          letterSpacing: '1px',
                          textTransform: 'uppercase',
                          color: statusColors[order.status],
                          padding: '4px 12px',
                          border: `1px solid ${statusColors[order.status]}`,
                        }}
                      >
                        {order.status}
                      </span>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '16px',
                        }}
                      >
                        <span
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontSize: '12px',
                            color: 'var(--warm-grey)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                          }}
                        >
                          <Clock size={12} strokeWidth={1.5} />
                          {order.date}
                        </span>
                      </div>
                      <span
                        style={{
                          fontFamily: "'Cormorant Garamond', serif",
                          fontWeight: 600,
                          fontSize: '20px',
                          color: 'var(--gold)',
                        }}
                      >
                        {formatPrice(order.total)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'saved' && (
              <div>
                <h2
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontWeight: 400,
                    fontSize: '28px',
                    color: 'var(--ink)',
                    marginBottom: '24px',
                  }}
                >
                  Saved Items
                </h2>
                <div
                  style={{
                    textAlign: 'center',
                    padding: '60px 0',
                    background: 'var(--cream)',
                  }}
                >
                  <Heart
                    size={48}
                    strokeWidth={1}
                    color="var(--muted)"
                    style={{ marginBottom: '16px' }}
                  />
                  <h3
                    style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontWeight: 400,
                      fontSize: '22px',
                      color: 'var(--ink)',
                      marginBottom: '8px',
                    }}
                  >
                    No saved items yet
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: 'var(--warm-grey)',
                      marginBottom: '24px',
                    }}
                  >
                    Items you save will appear here for quick access.
                  </p>
                  <Link
                    to="/search"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '12px 28px',
                      background: 'var(--gold)',
                      color: 'var(--ink)',
                      textDecoration: 'none',
                      fontFamily: "'Inter', sans-serif",
                      fontWeight: 600,
                      fontSize: '11px',
                      letterSpacing: '2px',
                      textTransform: 'uppercase',
                      transition: 'background 0.3s',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.background =
                        'var(--gold-dark)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.background = 'var(--gold)';
                    }}
                  >
                    Explore Products
                    <ChevronRight size={14} strokeWidth={1.5} />
                  </Link>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div>
                <h2
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontWeight: 400,
                    fontSize: '28px',
                    color: 'var(--ink)',
                    marginBottom: '24px',
                  }}
                >
                  Account Settings
                </h2>

                <div
                  style={{
                    background: 'var(--cream)',
                    padding: '32px',
                  }}
                >
                  {[
                    { label: 'Full Name', value: 'Priya Sharma' },
                    { label: 'Email', value: 'priya@email.com' },
                    { label: 'Phone', value: '981-9047099' },
                    { label: 'Address', value: 'Jutebikash, Laligurans Marg, Itahari' },
                  ].map((field) => (
                    <div
                      key={field.label}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '16px 0',
                        borderBottom: '1px solid var(--muted)',
                      }}
                    >
                      <div>
                        <span
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontSize: '10px',
                            fontWeight: 600,
                            letterSpacing: '1.5px',
                            textTransform: 'uppercase',
                            color: 'var(--gold)',
                            display: 'block',
                            marginBottom: '4px',
                          }}
                        >
                          {field.label}
                        </span>
                        <span
                          style={{
                            fontFamily: "'Inter', sans-serif",
                            fontSize: '15px',
                            color: 'var(--ink)',
                          }}
                        >
                          {field.value}
                        </span>
                      </div>
                      <button
                        style={{
                          background: 'none',
                          border: 'none',
                          color: 'var(--warm-grey)',
                          cursor: 'pointer',
                          fontFamily: "'Inter', sans-serif",
                          fontSize: '12px',
                          letterSpacing: '1px',
                          textTransform: 'uppercase',
                          transition: 'color 0.3s',
                        }}
                        onMouseEnter={(e) => {
                          (e.currentTarget as HTMLElement).style.color = 'var(--gold)';
                        }}
                        onMouseLeave={(e) => {
                          (e.currentTarget as HTMLElement).style.color = 'var(--warm-grey)';
                        }}
                      >
                        Edit
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />

      <style>{`
        @media (max-width: 768px) {
          .profile-layout {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
